const mysql = require('mysql2');
const querystring = require('querystring');

exports.handler = (event, context, callback) => {

    var conn = mysql.createConnection({
        host: "database-2.cw9yxxv7kuyu.us-east-1.rds.amazonaws.com",
        user: "admin",
        password: "leonardo1256",
        port: 3306,
        database: "inventariotest"
    });

    conn.connect(function(error) {
        if (error) {
            conn.end(function() {
                callback(error, {
                    statusCode: 400,
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        "estado": "ok",
                        "msg": error
                    }),
                });
            });
        }
        else {
            if (event.queryStringParameters != null) {
                var nombre = event.queryStringParameters.nombre;
                console.log(nombre);
            }
            if(event.body !== null && event.body !== undefined){
                var bodyBase64 = Buffer.from(event.body, 'base64').toString();
                var body = querystring.parse(bodyBase64);


                var nombre = body.nombre;

            }
            console.log("Conexion correcta a BD");
            conn.end(function() {
                callback(error, {
                    statusCode: 200,
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        "estado": "ok",
                        "body": body,
                        "nombre": nombre
                    }),
                });
            });

        }

    });

};
